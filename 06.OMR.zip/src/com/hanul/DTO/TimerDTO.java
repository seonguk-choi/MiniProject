package com.hanul.DTO;

import java.io.Serializable;

public class TimerDTO implements Serializable {

}
